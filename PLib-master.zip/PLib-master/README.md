# PLib
PLib - a MySQL wrapper for Garry's Mod.

PLib was made to make it easier to connect, modify and query a database with callback support.
